import webbrowser
import time

urls = [
    "http://localhost:8080/add?name=Sarah&email=sarah@gmail.com",
    "http://localhost:8080/add?name=Michael&email=michael@gmail.com",
    "http://localhost:8080/add?name=Jessica&email=jessica@gmail.com",
    "http://localhost:8080/add?name=David&email=david@gmail.com",
    "http://localhost:8080/add?name=Emily&email=emily@gmail.com",
    "http://localhost:8080/add?name=Daniel&email=daniel@gmail.com",
    "http://localhost:8080/add?name=Sophia&email=sophia@gmail.com",
    "http://localhost:8080/add?name=James&email=james@gmail.com",
    "http://localhost:8080/add?name=Olivia&email=olivia@gmail.com"
]

# open URL delay timer
for url in urls:
    webbrowser.open_new_tab(url)
    time.sleep(1)  # small delay
